/**
 * \addtogroup LCD_4BIT
 * @{
 */

/*****************************************************************************/
/**
 * \file LCD_I2C.c
 * LCD display routines for HD44780 compatible LCD controllers, with 4-bit
 * port-mapped interface.
 * \author Copyright (c) 2019, Murray R. Van Luyn. <vanluynm@duenna.science>
 * \version 0.0
 * \date 31-01-19
 */
/*****************************************************************************/

/*****************************************************************************
 *
 *     THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 *     OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *     WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *     ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 *     DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *     DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *     INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *     WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *     NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *     SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/

#include <LCD_4Bit.h>

/*****************************************************************************
 *
 *                      Private Global Variable Declarations
 *
 *****************************************************************************/
uint16_t _data_pins[4];

uint8_t _cols;
uint8_t _rows;
uint8_t _backlightval;
uint8_t _numlines;
uint8_t _displayfunction;
uint8_t _displaycontrol;
uint8_t _displaymode;


/*****************************************************************************
 *
 *                         Private Function Prototypes
 *
 *****************************************************************************/
void lcd_4bit_send(uint8_t value, uint8_t mode);
void lcd_4bit_write4bits(uint8_t value);
void lcd_4bit_pulseEnable(void);


/*****************************************************************************
 *
 *                        Private Function Implementation
 *
 *****************************************************************************/


/************ low level data pushing commands **********/

/*****************************************************************************
 *
 *                           lcd_4bit_send()
 *
 *****************************************************************************/
void lcd_4bit_send(uint8_t value, uint8_t mode)
{
  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_RS, mode);

  lcd_4bit_write4bits(value >> 4);
  lcd_4bit_write4bits(value);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_write4bits()
 *
 *****************************************************************************/
void lcd_4bit_write4bits(uint8_t value)
{
  for (uint8_t i = 0; i < 4; i++)
  {
	HAL_GPIO_WritePin(LCD_4BIT_PORT, _data_pins[i], (value >> i) & 0x01);
  }

  lcd_4bit_pulseEnable();

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_pulseEnable()
 *
 *****************************************************************************/
void lcd_4bit_pulseEnable(void)
{
  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_E, 1);
  HAL_Delay(0);                 // enable pulse must be >450ns

  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_E, 0);
  HAL_Delay(0);                 // commands need > 37us to settle

  return;
}


/*****************************************************************************
 *
 *                         Public Function Implementation
 *
 *****************************************************************************/

/*********** hook-in printf() */

int __io_putchar(int ch)
{
  lcd_4bit_write((uint8_t)ch);

  return(ch);
}


/*********** Interface */

/*****************************************************************************
 *
 *                              lcd_4bit_init()
 *
 *****************************************************************************/
void lcd_4bit_init(uint8_t lcd_cols, uint8_t lcd_rows)
{
  _cols = lcd_cols;
  _rows = lcd_rows;

  _data_pins[0] = LCD_4BIT_D4;
  _data_pins[1] = LCD_4BIT_D5;
  _data_pins[2] = LCD_4BIT_D6;
  _data_pins[3] = LCD_4BIT_D7;

  _displayfunction = LCD_4BIT_4BITMODE | LCD_4BIT_1LINE | LCD_4BIT_5x8DOTS;

  lcd_4bit_begin(_cols, _rows, LCD_4BIT_5x8DOTS);

  return;
}


/*****************************************************************************
 *
 *                              lcd_4bit_begin()
 *
 *****************************************************************************/
void lcd_4bit_begin(uint8_t cols, uint8_t lines, uint8_t dotsize)
{
  if (lines > 1)
  {
    _displayfunction |= LCD_4BIT_2LINE;
  }

  _numlines = lines;

  // for some 1 line displays you can select a 10 pixel high font
  if ((dotsize != 0) && (lines == 1))
  {
	_displayfunction |= LCD_4BIT_5x10DOTS;
  }

  // SEE PAGE 45/46 FOR INITIALIZATION SPECIFICATION!
  // according to datasheet, we need at least 40ms after power rises above 2.7V
  // before sending commands. We'll wait 50ms.
  HAL_Delay(50);

  // Now we pull both RS and R/W low to begin commands,
  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_RS, 0);
  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_RW, 0);

  // turn backlight off.
  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_BL, 0);

  HAL_Delay(1000);

  // put the LCD into 4 bit mode
  // this is according to the Hitachi HD44780 datasheet
  // figure 24, pg 46

  // we start in 8bit mode, try to set 4 bit mode
  lcd_4bit_write4bits(0x03);
  HAL_Delay(5);  // wait min 4.1ms

	// second try
  lcd_4bit_write4bits(0x03);
  HAL_Delay(5);  // wait min 4.1ms

	// third go!
  lcd_4bit_write4bits(0x03);
  HAL_Delay(0);  // wait > 150us

  // finally, set to 4-bit interface
  lcd_4bit_write4bits(0x02);

  // set # lines, font size, etc.
  lcd_4bit_command(LCD_4BIT_FUNCTIONSET | _displayfunction);

  // turn the display on with no cursor or blinking default
  _displaycontrol = LCD_4BIT_DISPLAYON | LCD_4BIT_CURSOROFF | LCD_4BIT_BLINKOFF;
  lcd_4bit_display();

  // clear it off
  lcd_4bit_clear();

  // Initialize to default text direction (for roman languages)
  _displaymode = LCD_4BIT_ENTRYLEFT | LCD_4BIT_ENTRYSHIFTDECREMENT;

  // set the entry mode
  lcd_4bit_command(LCD_4BIT_ENTRYMODESET | _displaymode);

  lcd_4bit_home();

  return;
}


/********** high level commands, for the user! */

/*****************************************************************************
 *
 *                            lcd_4bit_clear()
 *
 *****************************************************************************/
void lcd_4bit_clear(void)
{
  lcd_4bit_command(LCD_4BIT_CLEARDISPLAY); // clear display, set
                                         // cursor position to zero.

  HAL_Delay(2);  // wait min 2ms as this command takes a long time!

  return;
}

/*****************************************************************************
 *
 *                              lcd_4bit_home()
 *
 *****************************************************************************/
void lcd_4bit_home(void)
{
  lcd_4bit_command(LCD_4BIT_RETURNHOME);  // set cursor position to zero

  HAL_Delay(2);  // wait min 2ms as this command takes a long time!

  return;
}

/*****************************************************************************
 *
 *                             lcd_4bit_setCursor()
 *
 *****************************************************************************/
void lcd_4bit_setCursor(uint8_t col, uint8_t row)
{
  int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };

  if (row > _numlines)
  {
    row = _numlines - 1;    // we count rows starting w/0
  }

  lcd_4bit_command(LCD_4BIT_SETDDRAMADDR | (col + row_offsets[row]));

  return;
}

/*****************************************************************************
 *
 *                             lcd_4bit_noDisplay()
 *
 *****************************************************************************/
void lcd_4bit_noDisplay(void)
{
  // Turn the display off (quickly)

  _displaycontrol &= ~LCD_4BIT_DISPLAYON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                             lcd_4bit_display()
 *
 *****************************************************************************/
void lcd_4bit_display(void)
{
  // Turn the display on (quickly)

  _displaycontrol |= LCD_4BIT_DISPLAYON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                            lcd_4bit_noCursor()
 *
 *****************************************************************************/
void lcd_4bit_noCursor(void)
{
	// Turns the underline cursor off.

  _displaycontrol &= ~LCD_4BIT_CURSORON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                             lcd_4bit_cursor()
 *
 *****************************************************************************/
void lcd_4bit_cursor(void)
{
  // Turns the underline cursor on.

  _displaycontrol |= LCD_4BIT_CURSORON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                             lcd_4bit_noBlink()
 *
 *****************************************************************************/
void lcd_4bit_noBlink(void)
{
  // Turn off the blinking cursor.

  _displaycontrol &= ~LCD_4BIT_BLINKON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                              lcd_4bit_blink()
 *
 *****************************************************************************/
void lcd_4bit_blink(void)
{
  // Turn on the blinking cursor.

  _displaycontrol |= LCD_4BIT_BLINKON;
  lcd_4bit_command(LCD_4BIT_DISPLAYCONTROL | _displaycontrol);

  return;
}

/*****************************************************************************
 *
 *                        lcd_4bit_scrollDisplayLeft()
 *
 *****************************************************************************/

void lcd_4bit_scrollDisplayLeft(void)
{
  // These commands scroll the display without changing the RAM

  lcd_4bit_command(LCD_4BIT_CURSORSHIFT | LCD_4BIT_DISPLAYMOVE | LCD_4BIT_MOVELEFT);

  return;
}

/*****************************************************************************
 *
 *                        lcd_4bit_scrollDisplayRight()
 *
 *****************************************************************************/
void lcd_4bit_scrollDisplayRight(void)
{
  lcd_4bit_command(LCD_4BIT_CURSORSHIFT | LCD_4BIT_DISPLAYMOVE | LCD_4BIT_MOVERIGHT);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_leftToRight()
 *
 *****************************************************************************/
void lcd_4bit_leftToRight(void)
{
	// This is for text that flows Left to Right

  _displaymode |= LCD_4BIT_ENTRYLEFT;
  lcd_4bit_command(LCD_4BIT_ENTRYMODESET | _displaymode);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_rightToLeft()
 *
 *****************************************************************************/
void lcd_4bit_rightToLeft(void)
{
	// This is for text that flows Right to Left

  _displaymode &= ~LCD_4BIT_ENTRYLEFT;
  lcd_4bit_command(LCD_4BIT_ENTRYMODESET | _displaymode);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_autoscroll()
 *
 *****************************************************************************/
void lcd_4bit_autoscroll(void)
{
	// This will 'right justify' text from the cursor

  _displaymode |= LCD_4BIT_ENTRYSHIFTINCREMENT;
  lcd_4bit_command(LCD_4BIT_ENTRYMODESET | _displaymode);

  return;
}

/*****************************************************************************
 *
 *                          lcd_4bit_noAutoscroll()
 *
 *****************************************************************************/
void lcd_4bit_noAutoscroll(void)
{
  // This will 'left justify' text from the cursor

  _displaymode &= ~LCD_4BIT_ENTRYSHIFTINCREMENT;
  lcd_4bit_command(LCD_4BIT_ENTRYMODESET | _displaymode);

  return;
}

/*****************************************************************************
 *
 *                          lcd_4bit_createChar()
 *
 *****************************************************************************/
void lcd_4bit_createChar(uint8_t location, uint8_t charmap[])
{
  // Allows us to fill the first 8 CGRAM locations with custom characters

  location &= 0x7; // we only have 8 locations 0-7
  lcd_4bit_command(LCD_4BIT_SETCGRAMADDR | (location << 3));

  for (int i = 0; i < 8; i++)
  {
	lcd_4bit_write(charmap[i]);
  }

  return;
}

/*****************************************************************************
 *
 *                          lcd_4bit_noBacklight()
 *
 *****************************************************************************/
void lcd_4bit_noBacklight(void)
{
  // Turn the (optional) backlight off.

  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_BL, 0);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_backlight()
 *
 *****************************************************************************/
void lcd_4bit_backlight(void)
{
  // Turn the (optional) backlight on.

  HAL_GPIO_WritePin(LCD_4BIT_PORT, LCD_4BIT_BL, 1);

  return;
}


/*********** mid level commands, for sending data/cmds */

/*****************************************************************************
 *
 *                           lcd_4bit_command()
 *
 *****************************************************************************/
inline void lcd_4bit_command(uint8_t value)
{
  lcd_4bit_send(value, 0);

  return;
}

/*****************************************************************************
 *
 *                           lcd_4bit_write()
 *
 *****************************************************************************/
inline uint8_t lcd_4bit_write(uint8_t value)
{
  lcd_4bit_send(value, Rs);

  return(0);
}

/** @} */
