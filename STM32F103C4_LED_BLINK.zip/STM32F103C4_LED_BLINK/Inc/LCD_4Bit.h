/**
 * \addtogroup LCD_4BIT
 * @{
 */

/*****************************************************************************/
/**
 * \file LCD_4BIT.h
 * LCD display routines for HD44780 compatible LCD controllers, with 4-bit
 * port-mapped interface.
 * \author Copyright (c) 2019, Murray R. Van Luyn. <vanluynm@duenna.science>
 * \version 0.0
 * \date 31-01-19
 */
/*****************************************************************************/

/*****************************************************************************
 *
 *     THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 *     OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *     WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *     ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 *     DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *     DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *     INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *     WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *     NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *     SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************/


#ifndef LCD_4BIT_H
#define LCD_4BIT_H

#include "stm32f1xx_hal.h"
#include <stdio.h>

/**
 * Hardware LCD display port assignment.
 * Adjust \b LCD_4BIT_PORT to match hardware.
 * \hideinitializer
 */
#define LCD_4BIT_PORT GPIOA

#define LCD_4BIT_RS GPIO_PIN_1 // LCD I/O register select pin 4
#define LCD_4BIT_RW GPIO_PIN_2 // LCD I/O R/W select      pin 5
#define LCD_4BIT_E  GPIO_PIN_3 // LCD I/O enable          pin 6


#define LCD_4BIT_D4 GPIO_PIN_4  // LCD pin 11
#define LCD_4BIT_D5 GPIO_PIN_5  // LCD pin 12
#define LCD_4BIT_D6 GPIO_PIN_6 // LCD pin 13
#define LCD_4BIT_D7 GPIO_PIN_7 // LCD pin 14

#define LCD_4BIT_BL GPIO_PIN_9 // LCD Backlight


// commands
#define LCD_4BIT_CLEARDISPLAY 0x01
#define LCD_4BIT_RETURNHOME 0x02
#define LCD_4BIT_ENTRYMODESET 0x04
#define LCD_4BIT_DISPLAYCONTROL 0x08
#define LCD_4BIT_CURSORSHIFT 0x10
#define LCD_4BIT_FUNCTIONSET 0x20
#define LCD_4BIT_SETCGRAMADDR 0x40
#define LCD_4BIT_SETDDRAMADDR 0x80

// flags for display entry mode
#define LCD_4BIT_ENTRYRIGHT 0x00
#define LCD_4BIT_ENTRYLEFT 0x02
#define LCD_4BIT_ENTRYSHIFTINCREMENT 0x01
#define LCD_4BIT_ENTRYSHIFTDECREMENT 0x00

// flags for display on/off control
#define LCD_4BIT_DISPLAYON 0x04
#define LCD_4BIT_DISPLAYOFF 0x00
#define LCD_4BIT_CURSORON 0x02
#define LCD_4BIT_CURSOROFF 0x00
#define LCD_4BIT_BLINKON 0x01
#define LCD_4BIT_BLINKOFF 0x00

// flags for display/cursor shift
#define LCD_4BIT_DISPLAYMOVE 0x08
#define LCD_4BIT_CURSORMOVE 0x00
#define LCD_4BIT_MOVERIGHT 0x04
#define LCD_4BIT_MOVELEFT 0x00

// flags for function set
#define LCD_4BIT_8BITMODE 0x10
#define LCD_4BIT_4BITMODE 0x00
#define LCD_4BIT_2LINE 0x08
#define LCD_4BIT_1LINE 0x00
#define LCD_4BIT_5x10DOTS 0x04
#define LCD_4BIT_5x8DOTS 0x00

// flags for backlight control
#define LCD_4BIT_BACKLIGHT   0b00001000
#define LCD_4BIT_NOBACKLIGHT 0b00000000

#define En 0b00000100   // Enable bit
#define Rw 0b00000010   // Read/Write bit
#define Rs 0b00000001   // Register select bit


/*****************************************************************************
 *
 *                     Public Global Variable Declarations
 *
 *****************************************************************************/


/*****************************************************************************
 *
 *                              Macro Definitions
 *
 *****************************************************************************/


/*****************************************************************************
 *
 *                           Public Function Prototypes
 *
 *****************************************************************************/

/** 
 * Lcd module initialization function.
 * Initializes hardware and the HD44780 LCD display controller for 4 bit i2c
 * operation.
 * \param lcd_cols An \b uint8_t specifying LCD columns.
 * \param lcd_rows An \b uint8_t specifying LCD rows.
 * \return -
 */
extern void lcd_4bit_init(uint8_t lcd_cols, uint8_t lcd_rows);

extern void lcd_4bit_begin(uint8_t cols, uint8_t lines, uint8_t dotsize);

/**
 * Lcd module screen clear function.
 * Clear display, and set cursor position to zero.
 * \param -
 * \return -
 */
extern void lcd_4bit_clear();

/**
 * Lcd module cursor home function.
 * Set cursor position to zero.
 * \param -
 * \return -
 */
extern void lcd_4bit_home();

/**
 * Lcd module cursor set function.
 * Set cursor position to given column and row.
 * \param col An \b uint8_t specifying LCD columns.
 * \param row An \b uint8_t specifying LCD rows.
 * \return -
 */
extern void lcd_4bit_setCursor(uint8_t col, uint8_t row);

/**
 * Lcd module disable function.
 * Turn the display off (quickly).
 * \param -
 * \return -
 */
extern void lcd_4bit_noDisplay();

/**
 * Lcd module enable function.
 * Turn the display on (quickly).
 * \param -
 * \return -
 */
extern void lcd_4bit_display();

/**
 * Lcd module cursor control function.
 * Turns the underline cursor off.
 * \param -
 * \return -
 */
extern void lcd_4bit_noCursor();

/**
 * Lcd module cursor control function.
 * Turns the underline cursor on.
 * \param -
 * \return -
 */
extern void lcd_4bit_cursor();

/**
 * Lcd module cursor control function.
 * Turn off the blinking cursor.
 * \param -
 * \return -
 */
extern void lcd_4bit_noBlink();

/**
 * Lcd module cursor control function.
 * Turn on the blinking cursor.
 * \param -
 * \return -
 */
extern void lcd_4bit_blink();

/**
 * Lcd module scroll control function.
 * Scroll the display left without changing the RAM.
 * \param -
 * \return -
 */
extern void lcd_4bit_scrollDisplayLeft();

/**
 * Lcd module scroll control function.
 * Scroll the display right without changing the RAM.
 * \param -
 * \return -
 */
extern void lcd_4bit_scrollDisplayRight();

/**
 * Lcd module text direction control function.
 * For text that flows Left to Right.
 * \param -
 * \return -
 */
extern void lcd_4bit_leftToRight();

/**
 * Lcd module text direction control function.
 * For text that flows Right to Left.
 * \param -
 * \return -
 */
extern void lcd_4bit_rightToLeft();

/**
 * Lcd module autoscroll control function.
 * 'Right justify' text from the cursor.
 * \param -
 * \return -
 */
extern void lcd_4bit_autoscroll();

/**
 * Lcd module autoscroll control function.
 * 'Left justify' text from the cursor.
 * \param -
 * \return -
 */
extern void lcd_4bit_noAutoscroll();

/**
 * Lcd module custom character loading function.
 * Allows us to fill the first 8 CGRAM locations with
 * custom characters.
 * \param -
 * \return -
 */
extern void lcd_4bit_createChar(uint8_t, uint8_t[]);

/**
 * Lcd module backlight control function.
 * Turn the (optional) backlight off.
 * \param -
 * \return -
 */
extern void lcd_4bit_noBacklight();

/**
 * Lcd module backlight control function.
 * Turn the (optional) backlight on.
 * \param -
 * \return -
 */
extern void lcd_4bit_backlight();

extern void lcd_4bit_command(uint8_t);
extern uint8_t lcd_4bit_write(uint8_t);

#endif

/** @} */
